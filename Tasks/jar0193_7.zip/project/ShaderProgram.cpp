#include "ShaderProgram.h"
#include "Shader.h"

#include <cstdlib>
#include <iostream>
#include "Camera.h"

#include <glm/gtc/type_ptr.hpp>

ShaderProgram::ShaderProgram(const char* vertexFile, const char* fragmentFile)
    : programID(0)
{
    // Compile and link the shaders into one program.
    Shader vertexShader(GL_VERTEX_SHADER, vertexFile);
    Shader fragmentShader(GL_FRAGMENT_SHADER, fragmentFile);

    programID = glCreateProgram();
    if (programID == 0)
    {
        std::cerr << "Unable to create shader program" << std::endl;
        std::exit(EXIT_FAILURE);
    }

    glAttachShader(programID, vertexShader.getID());
    glAttachShader(programID, fragmentShader.getID());
    glLinkProgram(programID);

    GLint success = GL_FALSE;
    glGetProgramiv(programID, GL_LINK_STATUS, &success);
    if (!success) 
    {
        char infoLog[1024];
        glGetProgramInfoLog(programID, sizeof(infoLog), nullptr, infoLog);
        std::cerr << "Program link failed: " << vertexFile << " + "
                  << fragmentFile << '\n' << infoLog << std::endl;
        glDeleteProgram(programID);
        std::exit(EXIT_FAILURE);
    }

    // The linked program no longer needs the separate shader objects.
    glDetachShader(programID, vertexShader.getID());
    glDetachShader(programID, fragmentShader.getID());
}

ShaderProgram::~ShaderProgram()
{
    glDeleteProgram(programID);
}

void ShaderProgram::use() const
{
    glUseProgram(programID);
}


// Send three floating-point values to a uniform.
void ShaderProgram::setUniform(
    const char* name, float x, float y, float z) const
{
    GLint location = glGetUniformLocation(programID, name);

    if (location == -1)
    {
        std::cerr << "Uniform not found: " << name << std::endl;
        std::exit(EXIT_FAILURE);
    }

    use();
    glUniform3f(location, x, y, z);
}

void ShaderProgram::setUniform(
    const char* name, float value) const
{
    GLint location = glGetUniformLocation(programID, name);

    if (location == -1)
    {
        std::cerr << "Uniform not found: " << name << '\n';
        std::exit(EXIT_FAILURE);
    }

    use();
    glUniform1f(location, value);
}

void ShaderProgram::setUniform(
    const char* name,
    const glm::mat4& matrix
) const {
    GLint location = glGetUniformLocation(programID, name);

    if (location == -1) 
    {
        std::cerr << "Uniform not foundL: " << name << '\n';;
        std::exit(EXIT_FAILURE);
    }

    use();
    glUniformMatrix4fv(
        location,
        1,
        GL_FALSE,
        glm::value_ptr(matrix)
    );
}

void ShaderProgram::onCameraChanged(const Camera& camera){
    setUniform("viewMatrix", camera.getCamera());
    setUniform("projectionMatrix", camera.getProjectionMatrix());

    if (glGetUniformLocation(programID, "cameraPosition") != -1){
        const glm::vec3 position = camera.getPosition();

        setUniform(
            "cameraPosition",
            position.x,
            position.y,
            position.z
        );
    }
}



