
#include "Application.h"

#include <glad/gl.h>
#include <GLFW/glfw3.h>

#include <cstdlib>
#include <iostream>
#include <vector>
#include <random>

#include <chrono>
#include <ctime>
#include <glm/trigonometric.hpp>

#include "ShaderProgram.h"
#include "Model.h"
#include "DrawableObject.h"
#include "Scene.h"
#include "Sphere.h"
#include "tree.h"
#include "bushes.h"
#include "Login.h"
#include "sun.h"
#include "earth.h"
#include "moon.h"
#include "venator.h"
#include "imperial.h"
#include "plain.h"
#include "clock.h"


#include "Camera.h"
#include "Translation.h"
#include "Rotation.h"
#include "Scale.h"
#include "CompositeTransformation.h"



static constexpr bool updateViewportOnResize = true;
static constexpr bool updateProjectionOnResize = true;

static void error_callback(int error, const char* description){
    std::cerr << "GLFW error " << error << ": "
        << description << '\n';
}

static void key_callback(
    GLFWwindow* window, int key, int scancode, int action, int mods){
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(window, GLFW_TRUE);
    }
}

static void framebuffer_size_callback(
    GLFWwindow* window, int width, int height){
    if (updateViewportOnResize)
    {
        glViewport(0, 0, width, height);
    }
}

Application::Application(): window(nullptr){
    glfwSetErrorCallback(error_callback);

    if (!glfwInit()){
        std::cerr << "GLFW initialization failed\n";
        std::exit(EXIT_FAILURE);
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    window = glfwCreateWindow(800, 600, "ZPG", nullptr, nullptr);

    if (!window){
        std::cerr << "Window creation failed\n";
        glfwTerminate();
        std::exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    if (!gladLoadGL((GLADloadfunc)glfwGetProcAddress)){
        std::cerr << "GLAD initialization failed\n";
        glfwDestroyWindow(window);
        glfwTerminate();
        std::exit(EXIT_FAILURE);
    }
    glfwSetKeyCallback(window, key_callback);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
}


void Application::run()
{
    ShaderProgram colorProgram("shaders/basic.vert", "shaders/basic.frag");
    ShaderProgram yellowProgram("shaders/basic.vert", "shaders/yellow.frag");
    ShaderProgram treeProgram("tree.vert", "shaders/basic.frag");
    ShaderProgram clockProgram("clock.vert", "shaders/basic.frag");
    ShaderProgram bushProgram("bush.vert", "shaders/basic.frag");
    ShaderProgram phongProgram("phong.vert", "phong.frag");
    ShaderProgram blinnProgram("phong.vert", "blinn.frag");
    ShaderProgram ambientProgram("shaders/basic.vert", "ambient.frag");
    ShaderProgram lambertProgram("phong.vert", "lambert.frag");
    ShaderProgram normalTestProgram("normal_test.vert", "phong.frag");
    ShaderProgram specularTestProgram("phong.vert", "specular_test.frag");

    ShaderProgram nightTreeProgram("tree.vert", "night.frag");
    ShaderProgram nightBushProgram("bush.vert", "night.frag");
    ShaderProgram nightGroundProgram("phong.vert", "night.frag");

    Camera camera;

    camera.addObserver(colorProgram);
    camera.addObserver(yellowProgram);
    camera.addObserver(treeProgram);
    camera.addObserver(clockProgram);
    camera.addObserver(bushProgram);
    camera.addObserver(phongProgram);
    camera.addObserver(blinnProgram);
    camera.addObserver(ambientProgram);
    camera.addObserver(lambertProgram);
    camera.addObserver(normalTestProgram);
    camera.addObserver(specularTestProgram);

    camera.addObserver(nightTreeProgram);
    camera.addObserver(nightBushProgram);
    camera.addObserver(nightGroundProgram);

    // Create the login scene from the exported model.
    const GLsizei logoVertexCount = static_cast<GLsizei>(
        sizeof(loginVertices) / (6 * sizeof(float)));

    Model logoModel(loginVertices, logoVertexCount);
    DrawableObject logoObject(logoModel, colorProgram);

    Scene scene;
    scene.addObject(logoObject);

    // Create the sphere scene using the color shader.
    const GLsizei sphereVertexCount = static_cast<GLsizei>(
        sizeof(sphere) / (6 * sizeof(float)));

    Model sphereModel(sphere, sphereVertexCount);
    DrawableObject sphereObject(sphereModel, blinnProgram);

    sphereObject.getTransformation().scaleFactor = 0.35f;

    Scene sphereScene;

    Scale normalTestScale(1.5f, 0.5f, 1.0f);

    DrawableObject normalTestObject(sphereModel, normalTestProgram);
    normalTestObject.getTransformation().scaleFactor = 0.7f;
    normalTestObject.setTransformation(normalTestScale);

    Scene normalTestScene;
    normalTestScene.addObject(normalTestObject);


    DrawableObject specularTestObject(sphereModel, specularTestProgram);
    specularTestObject.getTransformation().scaleFactor = 0.7f;

    Scene specularTestScene;
    specularTestScene.addObject(specularTestObject);

    sphereScene.addObject(sphereObject);

    const glm::vec3 lightingPositions[] = {
     { 0.0f,  0.8f, 0.0f },
     { -0.8f,  0.0f, 0.0f },
     { 0.8f,  0.0f, 0.0f },
     { 0.0f, -0.8f, 0.0f }
    };

    std::vector<DrawableObject> lightingSpheres;
    lightingSpheres.reserve(4);

    Scene lightingScene;

    for (int i = 0; i < 4; ++i){
        lightingSpheres.emplace_back(sphereModel, lambertProgram);

        DrawableObject& object = lightingSpheres.back();
        Transformation& transform = object.getTransformation();

        transform.offsetX = lightingPositions[i].x;
        transform.offsetY = lightingPositions[i].y;
        transform.offsetZ = lightingPositions[i].z;
        transform.scaleFactor = 0.35f;

        lightingScene.addObject(object);
    }


    // Create a triangle with an RGB color for each vertex.
    const float triangleVertices[] = {
         0.0f,  0.5f, 0.0f,    1.0f, 0.0f, 0.0f,
        -0.5f, -0.5f, 0.0f,    0.0f, 1.0f, 0.0f,
         0.5f, -0.5f, 0.0f,    0.0f, 0.0f, 1.0f
    };

    const GLsizei triangleVertexCount = static_cast<GLsizei>(
        sizeof(triangleVertices) / (6 * sizeof(float)));

    Model triangleModel(triangleVertices, triangleVertexCount);
    DrawableObject triangleObject(triangleModel, colorProgram);

    Translation triangleTranslation(0.4f, 0.0f, 0.0f);
    Rotation triangleRotation(0.7854f, 0.0f, 0.0f, 1.0f);
    Scale triangleScale(0.6f, 0.6f, 0.6f);

    CompositeTransformation triangleMovement;
    triangleMovement.add(triangleTranslation);
    triangleMovement.add(triangleRotation);

    CompositeTransformation triangleTransformation;
    triangleTransformation.add(triangleMovement);
    triangleTransformation.add(triangleScale);

    triangleObject.setTransformation(triangleTransformation);

    Scene triangleScene;
    triangleScene.addObject(triangleObject);
   
    // Build the daytime forest from instances of one tree model.
    const GLsizei treeVertexCount = static_cast<GLsizei>(
        sizeof(tree) / (6 * sizeof(float)));

    Model treeModel(tree, treeVertexCount);
   
    const int treeCount = 74;
    std::vector<DrawableObject> trees;
    // Reserve space to keep object addresses valid while adding trees.
    trees.reserve(treeCount);

    Scene forestScene;


    //Ground for forest
    Model groundModel(plain, 6);
    DrawableObject groundObject(groundModel, colorProgram);

    Transformation& groundTransform =
        groundObject.getTransformation();

    groundTransform.scaleFactor = 10.0f;
    groundTransform.offsetY = -1.0f;

    forestScene.addObject(groundObject);

    std::mt19937 forestGenerator(std::random_device{}());

    std::uniform_real_distribution<float> forestX(-8.0f, 8.0f);
    std::uniform_real_distribution<float> forestZ(-8.0f, 8.0f);
    std::uniform_real_distribution<float> forestAngle(0.0f, 6.283185f);

    std::uniform_real_distribution<float> treeScaleRange(0.25f, 0.45f);
    std::uniform_real_distribution<float> bushScaleRange(1.0f, 2.0f);

    for (int i = 0; i < treeCount; ++i){
        trees.emplace_back(treeModel, treeProgram);

        DrawableObject& treeObject = trees.back();
        Transformation& t = treeObject.getTransformation();

        t.offsetX = forestX(forestGenerator);
        t.offsetY = -1.0f;
        t.offsetZ = forestZ(forestGenerator);
        t.scaleFactor = treeScaleRange(forestGenerator);
        t.angle = forestAngle(forestGenerator);

        forestScene.addObject(treeObject);
    }

    // Place smaller bushes between the trees.
    const GLsizei bushVertexCount = static_cast<GLsizei>(
        sizeof(bushes) / (6 * sizeof(float)));

    Model bushModel(bushes, bushVertexCount);

    const int bushCount = 25;
    std::vector<DrawableObject> bushObjects;
    bushObjects.reserve(bushCount);

    for (int i = 0; i < bushCount; ++i){
        bushObjects.emplace_back(bushModel, bushProgram);

        DrawableObject& bushObject = bushObjects.back();
        Transformation& t = bushObject.getTransformation();

        t.offsetX = forestX(forestGenerator);
        t.offsetY = -1.0f;
        t.offsetZ = forestZ(forestGenerator);
        t.scaleFactor = bushScaleRange(forestGenerator);
        t.angle = forestAngle(forestGenerator);

        forestScene.addObject(bushObject);
    }

    // Share the models and copy placement into the separate night scene.
    Scene nightForestScene;

    DrawableObject nightGroundObject(groundModel, nightGroundProgram);
    nightGroundObject.getTransformation() = groundObject.getTransformation();
    nightForestScene.addObject(nightGroundObject);

    std::vector<DrawableObject> nightTrees;
    nightTrees.reserve(treeCount);

    for (int i = 0; i < treeCount; ++i)
    {
        nightTrees.emplace_back(treeModel, nightTreeProgram);

        DrawableObject& object = nightTrees.back();
        object.getTransformation() = trees[i].getTransformation();

        // Leave a small clearing between the initial camera and the firefly.
        Transformation& transform = object.getTransformation();
        if (transform.offsetX > -2.0f && transform.offsetX < 2.0f
            && transform.offsetZ > -2.0f && transform.offsetZ < 5.0f)
        {
            transform.offsetX += transform.offsetX < 0.0f ? -4.0f : 4.0f;
        }

        nightForestScene.addObject(object);
    }

    std::vector<DrawableObject> nightBushes;
    nightBushes.reserve(bushCount);

    for (int i = 0; i < bushCount; ++i)
    {
        nightBushes.emplace_back(bushModel, nightBushProgram);

        DrawableObject& object = nightBushes.back();
        object.getTransformation() = bushObjects[i].getTransformation();

        Transformation& transform = object.getTransformation();
        if (transform.offsetX > -2.0f && transform.offsetX < 2.0f
            && transform.offsetZ > -2.0f && transform.offsetZ < 5.0f)
        {
            transform.offsetX += transform.offsetX < 0.0f ? -4.0f : 4.0f;
        }

        nightForestScene.addObject(object);
    }

    // Preserve tree and bush colors; use a brown ground material.
    nightTreeProgram.setUniform("useVertexColor", 1.0f);
    nightBushProgram.setUniform("useVertexColor", 1.0f);
    nightGroundProgram.setUniform("useVertexColor", 0.0f);
    nightGroundProgram.setUniform("materialColor", 0.18f, 0.12f, 0.06f);

    // Display the forest's point light as a small yellow sphere.
    DrawableObject fireflyObject(sphereModel, yellowProgram);

    Transformation& fireflyTransform = fireflyObject.getTransformation();
    fireflyTransform.offsetX = 0.0f;
    fireflyTransform.offsetY = -0.3f;
    fireflyTransform.offsetZ = 0.0f;
    fireflyTransform.scaleFactor = 0.05f;

    nightForestScene.addObject(fireflyObject);

    // Keep the original sun in the daytime forest.
    DrawableObject sunObject(sphereModel, yellowProgram);

    Transformation& sunTransform = sunObject.getTransformation();
    sunTransform.offsetX = 0.75f;
    sunTransform.offsetY = 0.78f;
    sunTransform.offsetZ = 0.5f;
    sunTransform.scaleFactor = 0.12f;

    forestScene.addObject(sunObject);

    // Share a small login signature across the other scenes.
    DrawableObject signatureObject(logoModel, yellowProgram);

    Transformation& signatureTransform =
        signatureObject.getTransformation();

    signatureTransform.offsetX = 0.70f;
    signatureTransform.offsetY = -0.90f;
    signatureTransform.offsetZ = -0.80f;
    signatureTransform.scaleFactor = 0.20f;
    signatureTransform.angle = 0.0f;

    sphereScene.addObject(signatureObject);
    triangleScene.addObject(signatureObject);
    forestScene.addObject(signatureObject);

    // Planet vertices contain position, color and normal.
    const GLsizei solarSunVertexCount = static_cast<GLsizei>(
        sizeof(sun) / (9 * sizeof(float)));
    const GLsizei earthVertexCount = static_cast<GLsizei>(
        sizeof(earth) / (9 * sizeof(float)));
    const GLsizei moonVertexCount = static_cast<GLsizei>(
        sizeof(moon) / (9 * sizeof(float)));

    Model solarSunModel(sun, solarSunVertexCount, 9);
    Model earthModel(earth, earthVertexCount, 9);
    Model moonModel(moon, moonVertexCount, 9);
    Model venatorModel(venatorVertices, venatorVertexCount, 9);
    Model imperialModel(imperialVertices, imperialVertexCount, 9);

    DrawableObject solarSunObject(solarSunModel, ambientProgram);
    DrawableObject earthObject(earthModel, phongProgram);
    DrawableObject moonObject(moonModel, blinnProgram);
    DrawableObject venatorObject(venatorModel, phongProgram);
    DrawableObject imperialObject(imperialModel, blinnProgram);

    Rotation solarSunSpin(0.0f, 0.0f, 1.0f, 0.0f);
    Scale solarSunScale(0.18f, 0.18f, 0.18f);
    CompositeTransformation solarSunTransformation;
    solarSunTransformation.add(solarSunSpin);
    solarSunTransformation.add(solarSunScale);
    solarSunObject.setTransformation(solarSunTransformation);

    // Keep Earth's orbital position separate from its size.
    Translation earthDistance(0.55f, 0.0f, 0.0f);
    Rotation earthOrbitRotation(0.0f, 0.0f, 0.0f, 1.0f);

    CompositeTransformation earthOrbit;
    earthOrbit.add(earthOrbitRotation);
    earthOrbit.add(earthDistance);

    Rotation earthSpin(0.0f, 1.0f, 0.0f, 0.0f);
    Scale earthScale(0.10f, 0.10f, 0.10f);

    CompositeTransformation earthTransformation;
    earthTransformation.add(solarSunObject.getTransformation());
    earthTransformation.add(earthOrbit);
    earthTransformation.add(earthSpin);
    earthTransformation.add(earthScale);
    earthObject.setTransformation(earthTransformation);

    // Position the Moon relative to Earth's orbital position.
    Translation moonDistance(0.20f, 0.0f, 0.0f);
    Rotation moonOrbitRotation(0.0f, 0.0f, 0.0f, 1.0f);

    CompositeTransformation moonOrbit;
    moonOrbit.add(moonOrbitRotation);
    moonOrbit.add(moonDistance);

    Rotation moonSpin(0.0f, 1.0f, 0.0f, 0.0f);
    Scale moonScale(0.045f, 0.045f, 0.045f);

    CompositeTransformation moonTransformation;
    moonTransformation.add(solarSunObject.getTransformation());
    moonTransformation.add(earthOrbit);
    moonTransformation.add(moonOrbit);
    moonTransformation.add(moonSpin);
    moonTransformation.add(moonScale);
    moonObject.setTransformation(moonTransformation);

    // Orbit around the vertical Y axis, moving toward and away from the camera.
    Rotation venatorOrbitRotation(0.0f, 0.0f, 1.0f, 0.0f);
    Rotation imperialOrbitRotation(0.0f, 0.0f, 1.0f, 0.0f);
    Translation venatorDistance(0.0f, 0.0f, 1.05f);
    Translation imperialDistance(0.0f, 0.0f, 1.40f);
    Rotation imperialFacing(glm::radians(180.0f), 0.0f, 0.0f, 1.0f);
    Rotation shipTilt(glm::radians(65.0f), 1.0f, 0.0f, 0.0f);
    Scale shipScale(0.28f, 0.28f, 0.28f);

    // Rotate the orbital offset before applying the ship's local tilt and size.
    CompositeTransformation venatorTransformation;
    venatorTransformation.add(solarSunObject.getTransformation());
    venatorTransformation.add(venatorOrbitRotation);
    venatorTransformation.add(venatorDistance);
    venatorTransformation.add(shipTilt);
    venatorTransformation.add(shipScale);
    venatorObject.setTransformation(venatorTransformation);

    CompositeTransformation imperialTransformation;
    imperialTransformation.add(solarSunObject.getTransformation());
    imperialTransformation.add(imperialOrbitRotation);
    imperialTransformation.add(imperialDistance);
    imperialTransformation.add(imperialFacing);
    imperialTransformation.add(shipTilt);
    imperialTransformation.add(shipScale);
    imperialObject.setTransformation(imperialTransformation);

    Scene solarScene;
    solarScene.addObject(solarSunObject);
    solarScene.addObject(earthObject);
    solarScene.addObject(moonObject);
    solarScene.addObject(venatorObject);
    solarScene.addObject(imperialObject);
    solarScene.addObject(signatureObject);


    const GLsizei clockVertexCount = static_cast<GLsizei>(
        sizeof(clockModel) / (9 * sizeof(float)));

    Model clockMesh(clockModel, clockVertexCount, 9);
    DrawableObject clockObject(clockMesh, clockProgram);

    // Reflect Z so the clock face points toward the camera.
    Scale clockFacing(1.0f, 1.0f, -1.0f);
    clockObject.setTransformation(clockFacing);

    Scene clockScene;
    clockScene.addObject(clockObject);

    // Place two clock instances in the forest.
    DrawableObject forestClock1(clockMesh, clockProgram);
    forestClock1.setTransformation(clockFacing);

    Transformation& firstClockTransform = forestClock1.getTransformation();

    firstClockTransform.offsetX = -1.5f;
    firstClockTransform.offsetY = -0.25f;
    firstClockTransform.offsetZ = 0.0f;
    firstClockTransform.scaleFactor = 0.75f;

    forestScene.addObject(forestClock1);

    DrawableObject forestClock2(clockMesh, clockProgram);
    forestClock2.setTransformation(clockFacing);

    Transformation& secondClockTransform =
        forestClock2.getTransformation();

    secondClockTransform.offsetX = 1.5f;
    secondClockTransform.offsetY = -0.25f;
    secondClockTransform.offsetZ = -3.0f;
    secondClockTransform.scaleFactor = 0.75f;

    forestScene.addObject(forestClock2);


    Scene* activeScene = &scene;
    DrawableObject* activeObject = &logoObject;

    int framebufferWidth, framebufferHeight;
    glfwGetFramebufferSize(window, &framebufferWidth, &framebufferHeight);

    glViewport(0, 0, framebufferWidth, framebufferHeight);
    camera.updateProjection(framebufferWidth, framebufferHeight);

    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

    glEnable(GL_DEPTH_TEST);

    Transformation& logoTransform = logoObject.getTransformation();
    
    logoTransform.offsetX = 0.0f;
    logoTransform.offsetY = 0.0f;
    logoTransform.angle = 0.5f;
    logoTransform.scaleFactor = 0.8f;

    float speed = 0.5f;
    float rotationSpeed = 1.0f;
    float scaleSpeed = 0.5f;
    double lastTime = glfwGetTime();
    float triangleAngle = 0.7854f;
    float earthOrbitAngle = 0.0f;
    float moonOrbitAngle = 0.0f;
    float earthSpinAngle = 0.0f;
    float moonSpinAngle = 0.0f;
    float solarSunSpinAngle = 0.0f;
    float venatorOrbitAngle = glm::radians(-45.0f);
    float imperialOrbitAngle = glm::radians(45.0f);
    const float shipOrbitSpeed = 0.35f;
    float cameraSpeed = 2.0f;

    normalTestProgram.setUniform("normalMode", 2.0f);

    double previousMouseX;
    double previousMouseY;

    glfwGetCursorPos(window, &previousMouseX, &previousMouseY);

    bool wasLooking = false;
    const float mouseSensitivity = 0.003f;

    Rotation hourHandRotation(0.0f, 0.0f, 0.0f, 1.0f);
    Rotation minuteHandRotation(0.0f, 0.0f, 0.0f, 1.0f);
    Rotation secondHandRotation(0.0f, 0.0f, 0.0f, 1.0f);

    //glClearColor(0.15f, 0.15f, 0.15f, 1.0f);

    specularTestProgram.setUniform("shininess", 1.0f);
    specularTestProgram.setUniform("clipBackfaceSpecular", 1.0f);
    
    while (!glfwWindowShouldClose(window))
    {
        // Use elapsed time to keep movement independent of frame rate.
        double currentTime = glfwGetTime();
        float deltaTime = static_cast<float>(currentTime - lastTime);
        lastTime = currentTime;
       // triangleAngle += 0.5f * deltaTime;      
        triangleRotation.setAngle(triangleAngle);

        // Update orbital rotations using elapsed time.
        earthOrbitAngle += 0.2f * deltaTime;
        moonOrbitAngle += 1.2f * deltaTime;
        earthOrbitRotation.setAngle(earthOrbitAngle);
        moonOrbitRotation.setAngle(moonOrbitAngle);

        // Move the ships around the Sun in opposite directions.
        venatorOrbitAngle += shipOrbitSpeed * deltaTime;
        imperialOrbitAngle -= shipOrbitSpeed * deltaTime;
        venatorOrbitRotation.setAngle(venatorOrbitAngle);
        imperialOrbitRotation.setAngle(imperialOrbitAngle);

        // Rotate each planet around its own local X axis.
        earthSpinAngle += 0.8f * deltaTime;
        moonSpinAngle += 0.6f * deltaTime;
        earthSpin.setAngle(earthSpinAngle);
        moonSpin.setAngle(moonSpinAngle);

        // Rotate the Sun around its own local Y axis.
        solarSunSpinAngle += 0.4f * deltaTime;
        solarSunSpin.setAngle(solarSunSpinAngle);

        // Select the scene and the object controlled by the keyboard.
        if (glfwGetKey(window, GLFW_KEY_1) == GLFW_PRESS){
            activeScene = &scene;
            activeObject = &logoObject;
        }
        if (glfwGetKey(window, GLFW_KEY_2) == GLFW_PRESS){
            activeScene = &sphereScene;
            activeObject = &sphereObject;
        }
        if (glfwGetKey(window, GLFW_KEY_3) == GLFW_PRESS){
            activeScene = &triangleScene;
            activeObject = &triangleObject;
        }
        if (glfwGetKey(window, GLFW_KEY_4) == GLFW_PRESS){
            activeScene = &forestScene;
            activeObject = &trees.front();
        }
        if (glfwGetKey(window, GLFW_KEY_5) == GLFW_PRESS){
            activeScene = &solarScene;
            activeObject = &solarSunObject;
        }
        if (glfwGetKey(window, GLFW_KEY_6) == GLFW_PRESS){
            activeScene = &clockScene;
            activeObject = &clockObject;
        }

        if (glfwGetKey(window, GLFW_KEY_7) == GLFW_PRESS) {
            activeObject = &lightingSpheres.front();
            activeScene = &lightingScene;
        }

        if (glfwGetKey(window, GLFW_KEY_8) == GLFW_PRESS){
            activeScene = &normalTestScene;
            activeObject = &normalTestObject;
        }

        if (glfwGetKey(window, GLFW_KEY_9) == GLFW_PRESS)
        {
            activeScene = &specularTestScene;
            activeObject = &specularTestObject;
        }

        if (glfwGetKey(window, GLFW_KEY_0) == GLFW_PRESS)
        {
            activeScene = &nightForestScene;
            activeObject = &fireflyObject;
        }

        Transformation& transform = activeObject->getTransformation();

        float& offsetX = transform.offsetX;
        float& offsetY = transform.offsetY;
        float& angle = transform.angle;
        float& scaleFactor = transform.scaleFactor;


        // Move, rotate and scale the selected object.
        if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS){
            offsetX -= speed * deltaTime;
        }
        if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS){
            offsetX += speed * deltaTime;
        }
        if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS){
            offsetY += speed * deltaTime;
        }
        if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS){
            offsetY -= speed * deltaTime;
        }
        if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS){
            angle -= rotationSpeed * deltaTime;
        }

        if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS){
            angle += rotationSpeed * deltaTime;
        }
        if (glfwGetKey(window, GLFW_KEY_Z) == GLFW_PRESS){
            scaleFactor -= scaleSpeed * deltaTime;
        }

        if (glfwGetKey(window, GLFW_KEY_X) == GLFW_PRESS){
            scaleFactor += scaleSpeed * deltaTime;
        }

        if (scaleFactor < 0.05f){
            scaleFactor = 0.05f;
        }
        //camera moovment
        if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS){
            camera.moveForward(cameraSpeed * deltaTime);
        }

        if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS){
            camera.moveForward(-cameraSpeed * deltaTime);
        }
        if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS){
            camera.moveRight(cameraSpeed * deltaTime);
        }

        if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS){
            camera.moveRight(-cameraSpeed * deltaTime);
        }
        
        double mouseX;
        double mouseY;
        glfwGetCursorPos(window, &mouseX, &mouseY);

        bool looking =
            glfwGetWindowAttrib(window, GLFW_FOCUSED) == GLFW_TRUE &&
            glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_RIGHT) == GLFW_PRESS;

        if (looking && wasLooking)
        {
            float deltaAlpha =
                static_cast<float>(mouseY - previousMouseY) * mouseSensitivity;

            float deltaFi =
                static_cast<float>(mouseX - previousMouseX) * mouseSensitivity;

            camera.rotate(deltaAlpha, deltaFi);
        }

        previousMouseX = mouseX;
        previousMouseY = mouseY;
        wasLooking = looking;

        glfwGetFramebufferSize(window, &framebufferWidth, &framebufferHeight);
        if (framebufferWidth <= 0 || framebufferHeight <= 0)
        {
            glfwPollEvents();
            continue;
        }

        if (updateProjectionOnResize)
        {
            camera.updateProjection(framebufferWidth, framebufferHeight);
        }

        // Render the selected scene and display the frame.
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        const auto now = std::chrono::system_clock::now();
        const auto wholeSeconds =
            std::chrono::floor<std::chrono::seconds>(now);

        const std::time_t timestamp =
            std::chrono::system_clock::to_time_t(wholeSeconds);

        std::tm localTime{};

        if (localtime_s(&localTime, &timestamp) != 0)
        {
            std::cerr << "Unable to read local time\n";
            std::exit(EXIT_FAILURE);
        }

        // Include fractional seconds for smooth movement.
        float seconds = static_cast<float>(localTime.tm_sec)
            + std::chrono::duration<float>(now - wholeSeconds).count();

        float minutes = static_cast<float>(localTime.tm_min)
            + seconds / 60.0f;

        float hours = static_cast<float>(localTime.tm_hour % 12)
            + minutes / 60.0f;

        const float clockwiseTurn = glm::radians(-360.0f);

        hourHandRotation.setAngle(clockwiseTurn * (hours / 12.0f));
        minuteHandRotation.setAngle(clockwiseTurn * (minutes / 60.0f));
        secondHandRotation.setAngle(clockwiseTurn * (seconds / 60.0f));

        clockProgram.setUniform("hourMatrix", hourHandRotation.getMatrix());
        clockProgram.setUniform("minuteMatrix", minuteHandRotation.getMatrix());
        clockProgram.setUniform("secondMatrix", secondHandRotation.getMatrix());


        glm::vec3 lightPosition(10.0f, 10.0f, 10.0f);

        if (activeScene == &lightingScene){
            lightPosition = glm::vec3(0.0f);
        }
        else if (activeScene == &solarScene){
            const Transformation& solarSunTransform =
                solarSunObject.getTransformation();

            lightPosition = glm::vec3(
                solarSunTransform.offsetX,
                solarSunTransform.offsetY,
                solarSunTransform.offsetZ
            );
        }else if (activeScene == &specularTestScene)
        {
            lightPosition = glm::vec3(0.0f, 0.0f, -3.0f);
        }
        else if (activeScene == &nightForestScene)
        {
            lightPosition = glm::vec3(
                fireflyTransform.offsetX,
                fireflyTransform.offsetY,
                fireflyTransform.offsetZ
            );
        }

        ShaderProgram* lightingPrograms[] = {
            &lambertProgram,
            &phongProgram,
            &blinnProgram,
            &normalTestProgram,
            &specularTestProgram,
            &nightTreeProgram,
            &nightBushProgram,
            &nightGroundProgram
        };

        for (ShaderProgram* program : lightingPrograms){
            program->setUniform(
                "lightPosition",
                lightPosition.x,
                lightPosition.y,
                lightPosition.z
            );
        }

        // Use the planets' original vertex colors in the solar scene.
        float useVertexColor = 0.0f;

        if (activeScene == &solarScene){
            useVertexColor = 1.0f;
        }

        ambientProgram.setUniform("useVertexColor", useVertexColor);
        phongProgram.setUniform("useVertexColor", useVertexColor);
        blinnProgram.setUniform("useVertexColor", useVertexColor);


        activeScene->draw();


        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glUseProgram(0);
}

Application::~Application()
{
    glfwDestroyWindow(window);
    glfwTerminate();
}
