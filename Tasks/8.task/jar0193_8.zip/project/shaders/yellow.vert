#version 410 core

layout (location = 0) in vec3 position;
layout (location = 1) in vec3 color;

out vec3 vertexColor;


void main()
{
    vertexColor = color ;
    gl_Position = vec4(position * 0.35 + vec3(0.5, 0.0, 0.0), 1.0);
}