#version 410 core

in vec3 vertexColor;
out vec4 FragColor;

void main()
{
    FragColor = vec4(1, 1, 0, 1.0);
}